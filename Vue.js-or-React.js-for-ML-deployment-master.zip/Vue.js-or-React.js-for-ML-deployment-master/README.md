# Vue.js-or-React.js-for-ML-deployment
Repository containing code for comparing Vue.js or React.js framework in deploying machine learning models

https://medium.com/@noahweber53/reactjs-or-vuejs-for-machine-learning-deployment-480122b1b760


Please note that the code is not 100% mine and that I consulted/copy&pasted a lot from documentation and online tutorials.
