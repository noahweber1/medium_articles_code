# NLP+Vue.js

This contains only the front end code. Backend is the "api" folder that you can insert your own endpoints and use as blueprint. 
